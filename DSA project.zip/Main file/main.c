#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#define MAX_VERTICES 100


#include "initlizeGraph.h"
#include "addEdge.h"
#include "isCyclic.h"
#include "removeEdge.h"
#include"isSimplified.h"
#include"removeExtraEdgeCyclic.h"
#include"removeExtraEdge.h"
#include"longestPath.h"
#include"printGraph.h"
#include "executeFunction.h"
#include"addDebts.h"
#include"interface.h"
#include"firstprogram.h"

int main()
{


    firstprogram();

    return 0;
}